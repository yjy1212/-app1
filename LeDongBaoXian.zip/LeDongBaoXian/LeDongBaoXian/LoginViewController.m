//
//  ViewController.m
//  LeDongBaoXian
//
//  Created by Apple on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "iToast.h"
#import "JSONKit.h"
#import "HttpUtils.h"
#import "AppDelegate.h"
#import "GlobalValues.h"
#import "HomeViewController.h"
#import "LoginViewController.h"
#import "RegisteredViewController.h"

@interface LoginViewController ()
@property (strong, nonatomic) IBOutlet UITextField *tf_UserName;
@property (strong, nonatomic) IBOutlet UITextField *tf_Password;
@property (strong, nonatomic) IBOutlet UIButton *btn_Registered;

- (IBAction)jumpToHomeViewController:(UIButton *)sender;

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.tf_UserName.backgroundColor = [UIColor clearColor];
    self.tf_Password.backgroundColor = [UIColor clearColor];
    
    self.tf_UserName.borderStyle = UITextBorderStyleNone;
    self.tf_Password.borderStyle = UITextBorderStyleNone;
    
    self.tf_Password.secureTextEntry = YES;
    
    self.btn_Registered.layer.borderColor = [UIColor whiteColor].CGColor;
    
    [self.btn_Registered addTarget:self action:@selector(jumpToRegisteredViewController) forControlEvents:UIControlEventTouchUpInside];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.tf_UserName resignFirstResponder];
    [self.tf_Password resignFirstResponder];
}

- (IBAction)jumpToHomeViewController:(UIButton *)sender {
    [HttpUtils loginWithLoginName:self.tf_UserName.text andLoginPwd:self.tf_Password.text completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
        if(!error){
            NSDictionary *responseInfo = [responseObject objectFromJSONData];
            NSString *errorCode = responseInfo[@"errorCode"];
            if([errorCode isEqualToString:@"0"]){
                [[[[iToast makeText:@"登录成功!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
                
                NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                GlobalUserID = responseInfo[@"userId"];
                GlobalUserToken = responseInfo[@"userToken"];
                GlobalUserPhone = self.tf_UserName.text;
                GlobalIsUserLogin = @"YES";
                GlobalIsFirstLogin = YES;
                [userDefaults setObject:GlobalUserID forKey:@"UserID"];
                [userDefaults setObject:GlobalUserPhone forKey:@"UserPhone"];
                [userDefaults setObject:GlobalUserToken forKey:@"Token"];
                [userDefaults setObject:GlobalIsUserLogin forKey:@"IsUserLogin"];
                
                HomeViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"Home"];
                AppDelegate *delegate = [UIApplication sharedApplication].delegate;
                delegate.window.rootViewController = vc;
                [delegate.window makeKeyAndVisible];
            }else{
                NSLog(@"%@", error);
                [[[[iToast makeText:@"账号或密码错误!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
            }
        }
    }];
    
}

- (void)jumpToRegisteredViewController{
    RegisteredViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"Registered"];
    [self.navigationController pushViewController:vc animated:YES];
}

@end
