//
//  ServeViewController.m
//  LeDongBaoXian
//
//  Created by Apple on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "ServeViewController.h"
#import "ClaimsViewController.h"
#import "OrderSearchViewController.h"
#import "CommunicationViewController.h"

@interface ServeViewController ()
@property (strong, nonatomic) IBOutlet UIView *v_Serve;
@property (strong, nonatomic) IBOutlet UIView *v_OrderSearch;
@property (strong, nonatomic) IBOutlet UIView *v_Claims;

@end

@implementation ServeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(jumpToCommunicationViewController)];
    [_v_Serve addGestureRecognizer:tapGesture];
    
    tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(jumpToOrderSearchViewController)];
    [_v_OrderSearch addGestureRecognizer:tapGesture];
    
    tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(jumpToClaimsViewController)];
    [_v_Claims addGestureRecognizer:tapGesture];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"服务";
    self.tabBarController.tabBar.hidden = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)jumpToCommunicationViewController{
    CommunicationViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"Communication"];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)jumpToOrderSearchViewController{
    OrderSearchViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"OrderSearch"];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)jumpToClaimsViewController{
    ClaimsViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"Claims"];
    [self.navigationController pushViewController:vc animated:YES];
}

@end
