//
//  DetailViewController.m
//  LeDongBaoXian
//
//  Created by Apple on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "PayViewController.h"
#import "DetailViewController.h"

@interface DetailViewController ()
@property (strong, nonatomic) IBOutlet UILabel *lb_Type;
@property (strong, nonatomic) IBOutlet UILabel *lb_Price;
@property (strong, nonatomic) IBOutlet UILabel *lb_Time;
@property (strong, nonatomic) IBOutlet UILabel *lb_Company;
@property (strong, nonatomic) IBOutlet UITextView *tv_Description;
- (IBAction)jumpToPayViewController:(UIButton *)sender;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _lb_Type.text = self.insurance.insuranceName;
    _lb_Price.text = self.insurance.insurancePrice;
    _lb_Time.text = self.insurance.insuranceTime;
    _lb_Company.text = self.insurance.insuranceName;
    _tv_Description.text = self.insurance.insuranceDescription;
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"产品信息";
    self.navigationController.navigationBar.items[self.currentIndex].title = @"返回";
    self.tabBarController.tabBar.hidden = YES;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)jumpToPayViewController:(UIButton *)sender {
    PayViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"Pay"];
    vc.insurance = self.insurance;
    vc.currentIndex = self.currentIndex + 1;
    [self.navigationController pushViewController:vc animated:YES];
}
@end
