//
//  PayView.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "PayView.h"

@implementation PayView
{
    BOOL isShowInputPage;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if(self = [super initWithFrame:frame]){
        [self setup];
    }
    return self;
}

- (void)setup{
    isShowInputPage = NO;
    
    UIView *background = [[UIView alloc] initWithFrame:self.frame];
    background.backgroundColor = [UIColor blackColor];
    background.alpha = 0.5;
    [self addSubview:background];
    
    self.contentView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, screen_Height-320*height_Offset, screen_Width*2, 320*height_Offset)];
    self.contentView.backgroundColor = [UIColor whiteColor];
    self.contentView.scrollEnabled = NO;
    self.contentView.pagingEnabled = NO;
    [self addSubview:self.contentView];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 10, 200, 20*height_Offset)];
    label.text = @"付款详情";
    label.font = [UIFont systemFontOfSize:17*height_Offset];
    label.center = CGPointMake(screen_Width/2, label.center.y);
    label.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:label];
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(10, 10, 15*width_Offset, 15*width_Offset)];
    [btn setBackgroundImage:[UIImage imageNamed:@"error"] forState:UIControlStateNormal];
    btn.center = CGPointMake(btn.center.x, label.center.y);
    [btn addTarget:self action:@selector(close) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:btn];
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(label.frame)+10, screen_Width, 0.5)];
    line.backgroundColor = [UIColor lightGrayColor];
    [self.contentView addSubview:line];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(8, CGRectGetMaxY(line.frame) + 10, 68*width_Offset, 18*height_Offset)];
    label.textColor = [UIColor lightGrayColor];
    label.text = @"订单信息";
    label.font = [UIFont systemFontOfSize:15*height_Offset];
    [self.contentView addSubview:label];
    
    self.lb_OrderInfo = [[UILabel alloc] initWithFrame:CGRectMake(20+68*width_Offset, label.frame.origin.y, screen_Width-20-68*width_Offset-20, 18*height_Offset)];
    self.lb_OrderInfo.textColor = [UIColor lightGrayColor];
    self.lb_OrderInfo.textAlignment = NSTextAlignmentRight;
    self.lb_OrderInfo.numberOfLines = 1;
    self.lb_OrderInfo.text = @"浙江移动...sdsds";
    self.lb_OrderInfo.font = [UIFont systemFontOfSize:15*height_Offset];
    [self.contentView addSubview:self.lb_OrderInfo];
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(label.frame)+10, screen_Width, 0.5)];
    line.backgroundColor = [UIColor lightGrayColor];
    [self.contentView addSubview:line];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(line.frame) + 10, 68*width_Offset, 18*height_Offset)];
    label.textColor = [UIColor lightGrayColor];
    label.text = @"付款方式";
    label.font = [UIFont systemFontOfSize:15*height_Offset];
    [self.contentView addSubview:label];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(screen_Width-20-68*width_Offset, CGRectGetMaxY(line.frame) + 10, 68*width_Offset, 18*height_Offset)];
    label.textColor = [UIColor lightGrayColor];
    label.textAlignment = NSTextAlignmentRight;
    label.font = [UIFont boldSystemFontOfSize:15*height_Offset];
    label.text = @"账户余额";
    [self.contentView addSubview:label];
    
    line = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(label.frame)+10, screen_Width, 0.5)];
    line.backgroundColor = [UIColor lightGrayColor];
    [self.contentView addSubview:line];
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(line.frame) + 24, 68*width_Offset, 18*height_Offset)];
    label.textColor = [UIColor blackColor];
    label.text = @"需付款";
    label.font = [UIFont systemFontOfSize:15*height_Offset];
    [self.contentView addSubview:label];
    
    self.lb_OrderPrice = [[UILabel alloc] initWithFrame:CGRectMake(20+68*width_Offset, label.frame.origin.y-3.5*height_Offset, screen_Width-20-68*width_Offset-20, 25*height_Offset)];
    self.lb_OrderPrice.textColor = [UIColor blackColor];
    self.lb_OrderPrice.textAlignment = NSTextAlignmentRight;
    self.lb_OrderPrice.font = [UIFont systemFontOfSize:18*height_Offset];
    self.lb_OrderPrice.text = @"222229.94元";
    [self.contentView addSubview:self.lb_OrderPrice];
    
    btn = [[UIButton alloc] initWithFrame:CGRectMake(10, 280*height_Offset-20, screen_Width-20, 40*height_Offset)];
    [btn setTitle:@"确          认" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn setBackgroundColor:barColor];
    btn.layer.cornerRadius = 8;
    btn.titleLabel.font = [UIFont systemFontOfSize:20*height_Offset];
    btn.layer.masksToBounds = YES;
    [btn addTarget:self action:@selector(gotoNextPage) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:btn];
    
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(screen_Width, 10, 200, 20*height_Offset)];
    label.text = @"输入密码";
    label.font = [UIFont systemFontOfSize:17*height_Offset];
    label.center = CGPointMake(screen_Width/2+screen_Width, label.center.y);
    label.textAlignment = NSTextAlignmentCenter;
    [self.contentView addSubview:label];
    
    
    btn = [[UIButton alloc] initWithFrame:CGRectMake(10+screen_Width, 10, 15*width_Offset, 15*width_Offset)];
    [btn setBackgroundImage:[UIImage imageNamed:@"arrow2"] forState:UIControlStateNormal];
    btn.center = CGPointMake(btn.center.x, label.center.y);
    [btn addTarget:self action:@selector(gotoLastPage) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:btn];
    
    line = [[UIView alloc] initWithFrame:CGRectMake(screen_Width, CGRectGetMaxY(label.frame)+10, screen_Width, 0.5)];
    line.backgroundColor = [UIColor lightGrayColor];
    [self.contentView addSubview:line];
    
    
    self.tf_Password = [[UITextField alloc] initWithFrame:CGRectMake(10+screen_Width, CGRectGetMaxY(line.frame) + 12, screen_Width-20, 40)];
    self.tf_Password.placeholder = @"请输入密码";
    self.tf_Password.font = [UIFont systemFontOfSize:18*height_Offset];
    self.tf_Password.borderStyle = UITextBorderStyleLine;
    self.tf_Password.layer.cornerRadius = 6;
    [self.contentView addSubview:self.tf_Password];
    
    btn = [[UIButton alloc] initWithFrame:CGRectMake(10+screen_Width, 280*height_Offset-20, screen_Width-20, 40*height_Offset)];
    [btn setTitle:@"确  认  付  款" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn setBackgroundColor:barColor];
    btn.layer.cornerRadius = 8;
    btn.titleLabel.font = [UIFont systemFontOfSize:20*height_Offset];
    btn.layer.masksToBounds = YES;
    [btn addTarget:self action:@selector(payMoney) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:btn];
    
}

- (void)show{
    isShowInputPage = NO;
    
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:self];
    self.contentView.transform = CGAffineTransformMakeTranslation(0, screen_Height);
    [UIView animateWithDuration:.5 animations:^{
        self.contentView.transform = CGAffineTransformIdentity;
    }];
}

- (void)showInputPage{
    isShowInputPage = YES;
    
    [self.contentView setContentOffset:CGPointMake(screen_Width, 0)];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:self];
    self.contentView.transform = CGAffineTransformMakeTranslation(0, screen_Height);
    [UIView animateWithDuration:.5 animations:^{
        self.contentView.transform = CGAffineTransformIdentity;
    }];
}

- (void)close{
    [self.contentView setContentOffset:CGPointMake(0, 0)];
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:self];
    self.contentView.transform = CGAffineTransformIdentity;
    [UIView animateWithDuration:.5 animations:^{
        self.contentView.transform = CGAffineTransformMakeTranslation(0, screen_Height);
    }];
    [self removeFromSuperview];
}

- (void)gotoNextPage{
    [self.contentView setContentOffset:CGPointMake(screen_Width, 0) animated:YES];
}

- (void)gotoLastPage{
    if(isShowInputPage){
        [self close];
    }else{
        [self.contentView setContentOffset:CGPointMake(0, 0) animated:YES];
    }
}

- (void)payMoney{
    [self close];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
