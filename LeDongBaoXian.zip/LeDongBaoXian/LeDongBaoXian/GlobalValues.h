//
//  GlobalValues.h
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface GlobalValues : NSObject

extern UIImage *GlobalUserHead;

extern NSString *GlobalUserID;

extern NSString *GlobalUserName;

extern NSString *GlobalUserToken;

extern NSString *GlobalUserGender;

extern NSString *GlobalUserPhone;

extern NSString *GlobalUserMoney;

extern NSString *GlobalUserIdentifyCode;

extern NSString *GlobalIsUserLogin;

extern NSString *GlobalVoice;

extern NSString *GlobalShock;

extern BOOL GlobalIsFirstLogin;

@end
