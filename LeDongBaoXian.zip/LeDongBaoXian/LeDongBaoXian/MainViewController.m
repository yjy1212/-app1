//
//  MainViewController.m
//  LeDongBaoXian
//
//  Created by Apple on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "JSONKit.h"
#import "HttpUtils.h"
#import "Insurance.h"
#import "MainTableViewCell.h"
#import "MainViewController.h"
#import "SearchViewController.h"
#import "DetailViewController.h"

@interface MainViewController () <UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate>
{
    NSMutableArray *insurances;
}
@property (strong, nonatomic) IBOutlet UISearchBar *sb_SearchBar;
@property (strong, nonatomic) IBOutlet UITableView *tv_TableView;

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _tv_TableView.delegate = self;
    _tv_TableView.dataSource = self;
    _tv_TableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    
    _sb_SearchBar.delegate = self;
    
    [self initData];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"首页";
    self.tabBarController.tabBar.hidden = NO;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)initData{
    insurances = [[NSMutableArray alloc] init];
    [HttpUtils getProductListWithProductName:@"" andProductType:@"" andProductID:@"" CompletionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
        if(!error){
            NSArray *responseInfo = [responseObject objectFromJSONData];
            for(NSDictionary *dic in responseInfo){
                Insurance *insurance = [[Insurance alloc] init];
                insurance.insuranceDescription = dic[@"description"];
                insurance.insuranceName = dic[@"name"];
                insurance.insurancePrice = dic[@"price"];
                insurance.insuranceTime = dic[@"productDate"];
                insurance.insuranceType = dic[@"type"];
                [insurances addObject:insurance];
            }
            [_tv_TableView reloadData];
        }else{
            NSLog(@"%@", error);
        }
    }];
}


#pragma mark - TableView Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return insurances.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60*height_Offset + 8;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainTableViewCell"];
    if(!cell){
        cell = [[MainTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MainTableViewCell"];
    }
    Insurance *insurance = insurances[indexPath.row];
    cell.iv_MainImage.image = insurance.insuranceImage;
    cell.lb_Type.text = insurance.insuranceName;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    DetailViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"Detail"];
    vc.insurance = insurances[indexPath.row];
    vc.currentIndex = 0;
    [self.navigationController pushViewController:vc animated:YES];
    
}


#pragma mark - SearchBar Delegate

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar{
    SearchViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"Search"];
    vc.insurances = insurances;
    [self.navigationController pushViewController:vc animated:YES];
    return NO;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
