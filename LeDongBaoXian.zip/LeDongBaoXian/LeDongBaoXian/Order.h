//
//  Order.h
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Order : NSObject

@property (copy, nonatomic) NSString *beneficiary;

@property (copy, nonatomic) NSString *dealID;

@property (copy, nonatomic) NSString *dealStatus;

@property (copy, nonatomic) NSString *orderID;

@property (copy, nonatomic) NSString *insurant;

@property (copy, nonatomic) NSString *pID;

@property (copy, nonatomic) NSString *policyholders;

@property (copy, nonatomic) NSString *userID;




@end
