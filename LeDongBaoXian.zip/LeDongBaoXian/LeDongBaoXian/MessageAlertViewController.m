//
//  MessageAlertViewController.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "GlobalValues.h"
#import "MessageAlertViewController.h"

@interface MessageAlertViewController ()
{
    NSUserDefaults *userDefaults;
}
@property (strong, nonatomic) IBOutlet UIView *v_Voice;
@property (strong, nonatomic) IBOutlet UIView *v_Shock;
@property (strong, nonatomic) IBOutlet UISwitch *s_Voice;
@property (strong, nonatomic) IBOutlet UISwitch *s_Shock;

@end

@implementation MessageAlertViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    userDefaults = [NSUserDefaults standardUserDefaults];
    
    _v_Voice.layer.borderColor = [UIColor lightGrayColor].CGColor;
    _v_Shock.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    _v_Voice.layer.borderWidth = 0.5;
    _v_Shock.layer.borderWidth = 0.5;
    
    if([GlobalVoice isEqualToString:@"YES"]){
        [_s_Voice setOn:YES];
    }else{
        [_s_Voice setOn:NO];
    }
    
    if([GlobalShock isEqualToString:@"YES"]){
        [_s_Shock setOn:YES];
    }else{
        [_s_Shock setOn:NO];
    }
    
    [_s_Voice addTarget:self action:@selector(transformVoiceSwitch) forControlEvents:UIControlEventValueChanged];
    [_s_Shock addTarget:self action:@selector(transformShockSwitch) forControlEvents:UIControlEventValueChanged];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"提醒设置";
    self.navigationController.navigationBar.items[1].title = @"返回";
    self.tabBarController.tabBar.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)transformVoiceSwitch{
    if(_s_Voice.isOn){
        GlobalVoice = @"YES";
    }else{
        GlobalVoice = @"NO";
    }
    [userDefaults setObject:GlobalVoice forKey:@"Voice"];
}

- (void)transformShockSwitch{
    if(_s_Shock.isOn){
        GlobalShock = @"YES";
    }else{
        GlobalShock = @"NO";
    }
    [userDefaults setObject:GlobalShock forKey:@"Shock"];
}


@end
