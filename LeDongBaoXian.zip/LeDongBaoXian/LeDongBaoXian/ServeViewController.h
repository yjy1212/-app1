//
//  ServeViewController.h
//  LeDongBaoXian
//
//  Created by Apple on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServeViewController : UIViewController

@end
