//
//  HttpUtils.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "JSONKit.h"
#import "HttpUtils.h"
#import <AFNetworking.h>

@implementation HttpUtils

+ (void)loginWithLoginName:(NSString *)loginName andLoginPwd:(NSString *)loginPwd completionHandler:(void (^)(NSURLResponse *response, id responseObject, NSError *error))completionHandler{
    
    NSDictionary *dic = [[NSDictionary alloc] initWithObjectsAndKeys:loginName, @"loginName", loginPwd, @"loginPwd", nil];
    NSString *json = [dic JSONString];
    NSDictionary *mDic = [[NSDictionary alloc] initWithObjectsAndKeys:@"702980", @"code", json, @"json", nil];
    
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] requestWithMethod:@"POST" URLString:@"http://121.42.196.238:8702/xn-account/api" parameters:mDic error:nil];
    NSURLSessionDataTask *task = [manager dataTaskWithRequest:request completionHandler:completionHandler];
    [task resume];
    
}

+ (void)getProductListWithProductName:(NSString *)productName andProductType:(NSString *)prodectType andProductID:(NSString *)productID CompletionHandler:(void (^)(NSURLResponse *response, id responseObject, NSError *error))completionHandler{
    
    NSDictionary *mDic = [[NSDictionary alloc] initWithObjectsAndKeys:productName, @"productName", prodectType, @"productType", productID, @"productId", nil];
    
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] requestWithMethod:@"POST" URLString:@"Http://121.42.163.54:8080/YueDongProject/GetProductListServlet" parameters:mDic error:nil];
    NSURLSessionDataTask *task = [manager dataTaskWithRequest:request completionHandler:completionHandler];
    [task resume];
    
}

+ (void)setUserInfoWithUserID:(NSString *)userID andUserName:(NSString *)userName andUserGender:(NSString *)userGender andUserMoney:(NSString *)userMoney completionHandler:(void (^)(NSURLResponse *response, id responseObject, NSError *error))completionHandler{
    NSDictionary *mDic = [[NSDictionary alloc] initWithObjectsAndKeys:userID, @"userId", userName, @"userName", userGender, @"userSex", userMoney, @"userMoney", nil];
    
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] requestWithMethod:@"POST" URLString:@"Http://121.42.163.54:8080/YueDongProject/SetUserInfoServlet" parameters:mDic error:nil];
    NSURLSessionDataTask *task = [manager dataTaskWithRequest:request completionHandler:completionHandler];
    [task resume];
}

+ (void)getUserInfoWithUserID:(NSString *)userID completionHandler:(void (^)(NSURLResponse *response, id responseObject, NSError *error))completionHandler{
    
    NSDictionary *mDic = [[NSDictionary alloc] initWithObjectsAndKeys:userID, @"userId", nil];
    
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] requestWithMethod:@"POST" URLString:@"Http://121.42.163.54:8080/YueDongProject/GetUserInfoServlet" parameters:mDic error:nil];
    NSURLSessionDataTask *task = [manager dataTaskWithRequest:request completionHandler:completionHandler];
    [task resume];
    
}

+ (void)addOrderWithProductID:(NSString *)productId andUserID:(NSString *)userID andPolicyholders:(NSString *)policyholders andInsurant:(NSString *)insurant andBeneficiary:(NSString *)beneficiary andDealID:(NSString *)dealID completionHandler:(void (^)(NSURLResponse *response, id responseObject, NSError *error))completionHandler{
    
    NSDictionary *mDic = [[NSDictionary alloc] initWithObjectsAndKeys:productId, @"productId", userID, @"userId", policyholders, @"policyholders", insurant, @"insurant", beneficiary, @"beneficiary", dealID, @"dealId", nil];
    
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] requestWithMethod:@"POST" URLString:@"Http://121.42.163.54:8080/YueDongProject/AddOneOrderServlet" parameters:mDic error:nil];
    NSURLSessionDataTask *task = [manager dataTaskWithRequest:request completionHandler:completionHandler];
    [task resume];
    
}

+ (void)getOrderWithOrderID:(NSString *)orderID andUserID:(NSString *)userID andProductID:(NSString *)productId completionHandler:(void (^)(NSURLResponse *response, id responseObject, NSError *error))completionHandler{
    
    NSDictionary *mDic = [[NSDictionary alloc] initWithObjectsAndKeys:productId, @"productId", userID, @"userId", orderID, @"orderId", nil];
    
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] requestWithMethod:@"POST" URLString:@"Http://121.42.163.54:8080/YueDongProject/GetOrderServlet" parameters:mDic error:nil];
    NSURLSessionDataTask *task = [manager dataTaskWithRequest:request completionHandler:completionHandler];
    [task resume];
}


@end
