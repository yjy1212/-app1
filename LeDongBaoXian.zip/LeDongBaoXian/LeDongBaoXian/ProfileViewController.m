//
//  ProfileViewController.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "GlobalValues.h"
#import "SettingViewController.h"
#import "ProfileViewController.h"

@interface ProfileViewController ()

@property (strong, nonatomic) IBOutlet UIImageView *iv_UserHead;
@property (strong, nonatomic) IBOutlet UILabel *lb_UserName;
@property (strong, nonatomic) IBOutlet UILabel *lb_Gender;
@property (strong, nonatomic) IBOutlet UILabel *lb_Phone;

- (IBAction)jumpToSettingViewController:(UIButton *)sender;

@end

@implementation ProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"个人中心";
    self.tabBarController.tabBar.hidden = NO;
    
    if(GlobalUserHead){
        _iv_UserHead.image = GlobalUserHead;
    }
    if(GlobalUserName && ![GlobalUserName isEqualToString:@""]){
        _lb_UserName.text = GlobalUserName;
    }
    if(GlobalUserGender && ![GlobalUserGender isEqualToString:@""]){
        _lb_Gender.text = GlobalUserGender;
    }
    if(GlobalUserPhone && ![GlobalUserPhone isEqualToString:@""]){
        _lb_Phone.text = GlobalUserPhone;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)jumpToSettingViewController:(UIButton *)sender {
    SettingViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"Setting"];
    [self.navigationController pushViewController:vc animated:YES];
}
@end
