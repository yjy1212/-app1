//
//  GlobalValues.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "GlobalValues.h"

@implementation GlobalValues


UIImage *GlobalUserHead;

NSString *GlobalUserID;

NSString *GlobalUserName;

NSString *GlobalUserToken;

NSString *GlobalUserGender;

NSString *GlobalUserPhone;

NSString *GlobalUserMoney;

NSString *GlobalUserIdentifyCode;

NSString *GlobalIsUserLogin;

NSString *GlobalVoice;

NSString *GlobalShock;

BOOL GlobalIsFirstLogin;

@end
