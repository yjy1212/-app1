//
//  CommunicationViewController.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "GlobalValues.h"
#import "CommunicationTableViewCell.h"
#import "CommunicationViewController.h"

@interface CommunicationViewController () <UITableViewDelegate, UITableViewDataSource>
{
    NSMutableArray *messages;
    NSMutableArray *cells;
}

@property (strong, nonatomic) IBOutlet UITableView *tv_tableView;

@property (strong, nonatomic) IBOutlet UITextView *tv_TextView;

- (IBAction)sendMessage:(UIButton *)sender;

@end

@implementation CommunicationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _tv_tableView.backgroundColor = [UIColor lightGrayColor];
    _tv_tableView.delegate = self;
    _tv_tableView.dataSource= self;
    _tv_tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    _tv_TextView.layer.borderWidth = 1;
    _tv_TextView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    _tv_TextView.layer.cornerRadius = 8;
    
    messages = [[NSMutableArray alloc] init];
    cells = [[NSMutableArray alloc] init];
    
    
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"联系客服";
    self.navigationController.navigationBar.items[0].title = @"返回";
    self.tabBarController.tabBar.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return messages.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return ((Message *)messages[indexPath.row]).cellHeight;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
//    CommunicationTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommunicationTableViewCell"];
//    if(!cell){
//        cell = [[CommunicationTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CommunicationTableViewCell"];
//    }
//    Message *message = messages[indexPath.row];
//    message.cellHeight = [cell setMessage:message];
    return cells[indexPath.row];
}

- (IBAction)sendMessage:(UIButton *)sender {
    if([_tv_TextView.text isEqualToString:@""]){
        return;
    }
    Message *message = [[Message alloc] init];
    message.content = _tv_TextView.text;
    message.userHead = [UIImage imageNamed:@"beach"];
    message.userName = GlobalUserName;
    message.isSender = YES;
    [messages addObject:message];
    
    CommunicationTableViewCell *cell = [[CommunicationTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CommunicationTableViewCell"];
    message.cellHeight = [cell setMessage:message];
    [cells addObject:cell];
    
    [_tv_tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:messages.count-1 inSection:0]] withRowAnimation:UITableViewRowAnimationBottom];
    [_tv_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:messages.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}


@end
