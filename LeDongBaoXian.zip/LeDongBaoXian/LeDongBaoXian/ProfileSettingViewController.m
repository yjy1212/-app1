//
//  ProfileSettingViewController.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "iToast.h"
#import "JSONKit.h"
#import "HttpUtils.h"
#import "GlobalValues.h"
#import "ProfileSettingViewController.h"

@interface ProfileSettingViewController () <UINavigationControllerDelegate, UIImagePickerControllerDelegate>
@property (strong, nonatomic) IBOutlet UILabel *lb_UserGender;
@property (strong, nonatomic) IBOutlet UILabel *lb_UserName;
@property (strong, nonatomic) IBOutlet UIImageView *iv_UserHead;
@property (strong, nonatomic) IBOutlet UILabel *lb_ModifyUserName;
@property (strong, nonatomic) IBOutlet UILabel *lb_ModifyUserGender;

@end

@implementation ProfileSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _iv_UserHead.userInteractionEnabled = YES;
    _lb_ModifyUserName.userInteractionEnabled = YES;
    _lb_ModifyUserGender.userInteractionEnabled = YES;
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(modifyUserHead)];
    [_iv_UserHead addGestureRecognizer:tapGesture];
    
    tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(modifyUserName)];
    [_lb_ModifyUserName addGestureRecognizer:tapGesture];
    
    tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(modifyUserGender)];
    [_lb_ModifyUserGender addGestureRecognizer:tapGesture];
    
    if(GlobalUserHead){
        _iv_UserHead.image = GlobalUserHead;
    }
    if(GlobalUserName && ![GlobalUserName isEqualToString:@""]){
        _lb_UserName.text = GlobalUserName;
    }
    if(GlobalUserGender && ![GlobalUserGender isEqualToString:@""]){
        _lb_UserGender.text = GlobalUserGender;
    }
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"资料设置";
    self.navigationController.navigationBar.items[1].title = @"返回";
    self.tabBarController.tabBar.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)modifyUserHead{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.allowsEditing = YES;
    imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePicker.delegate = self;
    [self presentViewController:imagePicker animated:YES completion:nil];
}

- (void)modifyUserName{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"修改用户名" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = @"请输入用户名";
    }];
    
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        _lb_UserName.text = alertController.textFields.firstObject.text;
        GlobalUserName = _lb_UserName.text;
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        [userDefaults setObject:GlobalUserName forKey:@"UserName"];
        
        [HttpUtils setUserInfoWithUserID:GlobalUserID andUserName:GlobalUserName andUserGender:@"" andUserMoney:@"" completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
            if(!error){
                NSDictionary *responseInfo = [responseObject objectFromJSONData];
                NSString *code = responseInfo[@"code"];
                if([code isEqualToString:@"1"]){
                    [[[[iToast makeText:@"修改用户名成功!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
                }else{
                    NSLog(@"%@", code);
                }
            }else{
                NSLog(@"%@", error);
            }
        }];
    }];
    
    UIAlertAction *cancleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    
    [alertController addAction:okAction];
    [alertController addAction:cancleAction];
    
    [self presentViewController:alertController animated:YES completion:nil];
    
}

- (void)modifyUserGender{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"修改性别" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *manAction = [UIAlertAction actionWithTitle:@"男" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        _lb_UserGender.text = @"男";
        GlobalUserGender = @"男";
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        [userDefaults setObject:GlobalUserGender forKey:@"UserGender"];
        
    }];
    
    UIAlertAction *womanAction = [UIAlertAction actionWithTitle:@"女" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        _lb_UserGender.text = @"女";
        GlobalUserGender = @"女";
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        [userDefaults setObject:GlobalUserGender forKey:@"UserGender"];
        
    }];
    
    [alertController addAction:manAction];
    [alertController addAction:womanAction];
    
    [self presentViewController:alertController animated:YES completion:^{
        [HttpUtils setUserInfoWithUserID:GlobalUserID andUserName:@"" andUserGender:GlobalUserGender andUserMoney:@"" completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
            if(!error){
                NSDictionary *responseInfo = [responseObject objectFromJSONData];
                NSString *code = responseInfo[@"code"];
                if([code isEqualToString:@"1"]){
                    [[[[iToast makeText:@"修改性别成功!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
                }else{
                    NSLog(@"%@", code);
                }
            }else{
                NSLog(@"%@", error);
            }
        }];
    }];
    

}


#pragma mark - ImagePickerController Delegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    UIImage *image = info[@"UIImagePickerControllerEditedImage"];
    if(image){
        self.iv_UserHead.image = image;
        GlobalUserHead = image;
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        [userDefaults setObject:UIImagePNGRepresentation(image) forKey:@"UserHead"];
        image = nil;
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}

@end
