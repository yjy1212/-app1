//
//  Insurance.h
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface Insurance : NSObject

@property (copy, nonatomic) NSString *insuranceID;

@property (copy, nonatomic) NSString *insuranceType;

@property (copy, nonatomic) NSString *insuranceName;

@property (copy, nonatomic) NSString *insuranceDescription;

@property (copy, nonatomic) NSString *insurancePrice;

@property (copy, nonatomic) NSString *insuranceCompany;

@property (copy, nonatomic) NSString *insuranceTime;

@property (nonatomic) UIImage *insuranceImage;

@end
