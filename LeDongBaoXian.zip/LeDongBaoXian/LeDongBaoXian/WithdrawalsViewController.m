//
//  WithdrawalsViewController.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "iToast.h"
#import "PayView.h"
#import "WithdrawalsViewController.h"

@interface WithdrawalsViewController ()

@property (strong, nonatomic) IBOutlet UITextField *tf_Account;
@property (strong, nonatomic) IBOutlet UITextField *tf_Price;

@property (strong, nonatomic) PayView *payView;

- (IBAction)nextStep:(UIButton *)sender;


@end

@implementation WithdrawalsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.payView = [[PayView alloc] initWithFrame:self.view.frame];
    
    _tf_Account.borderStyle = UITextBorderStyleNone;
    _tf_Price.borderStyle = UITextBorderStyleNone;
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"提现";
    self.navigationController.navigationBar.items[0].title = @"返回";
    self.tabBarController.tabBar.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)nextStep:(UIButton *)sender {
    if([_tf_Account.text isEqualToString:@""]){
        [[[[iToast makeText:@"请输入转出账户!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
        return;
    }
    if([_tf_Price.text isEqualToString:@""]){
        [[[[iToast makeText:@"请输入金额!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
        return;
    }
    [self.payView showInputPage];
}

@end
