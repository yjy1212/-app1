//
//  OrderSearchViewController.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "Order.h"
#import "iToast.h"
#import "JSONKit.h"
#import "HttpUtils.h"
#import "OrderSearchViewController.h"
#import "SearchResultViewController.h"

@interface OrderSearchViewController ()
@property (strong, nonatomic) IBOutlet UITextField *tf_SearchType;
@property (strong, nonatomic) IBOutlet UITextField *tf_OrderNumber;
@property (strong, nonatomic) IBOutlet UITextField *tf_IdentifyCode;

- (IBAction)jumpToDetailViewController:(UIButton *)sender;

@end

@implementation OrderSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _tf_SearchType.borderStyle = UITextBorderStyleNone;
    _tf_OrderNumber.borderStyle = UITextBorderStyleNone;
    _tf_IdentifyCode.borderStyle = UITextBorderStyleNone;
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"保单查询";
    self.navigationController.navigationBar.items[0].title = @"返回";
    self.tabBarController.tabBar.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [_tf_IdentifyCode resignFirstResponder];
    [_tf_OrderNumber resignFirstResponder];
    [_tf_SearchType resignFirstResponder];
}

- (IBAction)jumpToDetailViewController:(UIButton *)sender {
    int num = 0;
    NSString *number = @"";
    NSString *type = @"";
    NSString *identify = @"";
    if(![_tf_OrderNumber.text isEqualToString:@""]){
        num++;
        number = _tf_OrderNumber.text;
    }
    if(![_tf_SearchType.text isEqualToString:@""]){
        num++;
        type = _tf_SearchType.text;
    }
    if(![_tf_IdentifyCode.text isEqualToString:@""]){
        num++;
        identify = _tf_IdentifyCode.text;
    }
    if(num != 1){
        [[[[iToast makeText:@"只允许一个查询条件!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
        return;
    }
    
    [HttpUtils getOrderWithOrderID:@"" andUserID:@"21321" andProductID:@"" completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
        if(!error){
            NSArray *responseInfo = [responseObject objectFromJSONData];
            NSMutableArray *results = [[NSMutableArray alloc] init];
            if(responseInfo.count >= 1 ){
                for(NSDictionary *dic in responseInfo){
                    Order *order = [[Order alloc] init];
                    order.beneficiary = dic[@"beneficiary"];
                    order.dealID = dic[@"dealID"];
                    order.dealStatus = dic[@"dealStatus"];
                    order.orderID = dic[@"id"];
                    order.insurant = dic[@"insurant"];
                    order.pID = dic[@"pId"];
                    order.policyholders = dic[@"policyholders"];
                    order.userID = dic[@"userID"];
                    [results addObject:order];
                }
                SearchResultViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"SearchResult"];
                vc.results = results;
                [self.navigationController pushViewController:vc animated:YES];
            }else{
                [[[[iToast makeText:@"无此订单!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
            }
        }else{
            NSLog(@"%@", error);
        }
    }];
}


@end
