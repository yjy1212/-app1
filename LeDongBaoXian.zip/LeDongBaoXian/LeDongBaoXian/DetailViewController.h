//
//  DetailViewController.h
//  LeDongBaoXian
//
//  Created by Apple on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "Insurance.h"
#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property (nonatomic) Insurance *insurance;

@property (assign, nonatomic) NSInteger currentIndex;

@end
