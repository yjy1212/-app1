//
//  HttpUtils.h
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HttpUtils : NSObject

+ (void)loginWithLoginName:(NSString *)loginName andLoginPwd:(NSString *)loginPwd completionHandler:(void (^)(NSURLResponse *response, id responseObject, NSError *error))completionHandler;

+ (void)getProductListWithProductName:(NSString *)productName andProductType:(NSString *)prodectType andProductID:(NSString *)productID CompletionHandler:(void (^)(NSURLResponse *response, id responseObject, NSError *error))completionHandler;

+ (void)setUserInfoWithUserID:(NSString *)userID andUserName:(NSString *)userName andUserGender:(NSString *)userGender andUserMoney:(NSString *)userMoney completionHandler:(void (^)(NSURLResponse *response, id responseObject, NSError *error))completionHandler;

+ (void)getUserInfoWithUserID:(NSString *)userID completionHandler:(void (^)(NSURLResponse *response, id responseObject, NSError *error))completionHandler;

+ (void)addOrderWithProductID:(NSString *)productId andUserID:(NSString *)userID andPolicyholders:(NSString *)policyholders andInsurant:(NSString *)insurant andBeneficiary:(NSString *)beneficiary andDealID:(NSString *)dealID completionHandler:(void (^)(NSURLResponse *response, id responseObject, NSError *error))completionHandler;

+ (void)getOrderWithOrderID:(NSString *)orderID andUserID:(NSString *)userID andProductID:(NSString *)productId completionHandler:(void (^)(NSURLResponse *response, id responseObject, NSError *error))completionHandler;

@end
