//
//  CommunicationTableViewCell.h
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "Message.h"
#import <UIKit/UIKit.h>

@interface CommunicationTableViewCell : UITableViewCell

@property (strong, nonatomic) UIImageView *iv_UserHead;

@property (strong, nonatomic) UILabel *lb_UserName;

@property (strong, nonatomic) UILabel *lb_Content;


- (CGFloat)setMessage:(Message *)message;

@end
