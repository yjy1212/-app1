//
//  CommunicationTableViewCell.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "CommunicationTableViewCell.h"

@implementation CommunicationTableViewCell
{
    UIImageView *background;
    UIImage *leftBubble;
    UIImage *rightBubble;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if(self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]){
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self initView];
    }
    return self;
}

- (void)initView{
    _iv_UserHead = [[UIImageView alloc] initWithFrame:CGRectMake(10, 5, 50, 50)];
    _iv_UserHead.layer.masksToBounds = YES;
    _iv_UserHead.layer.cornerRadius = 25;
    
    _lb_UserName = [[UILabel alloc] initWithFrame:CGRectMake(70, 10, 100, 20)];
    
    _lb_Content = [[UILabel alloc] initWithFrame:CGRectMake(60, 85, 200, 20)];
    _lb_Content.numberOfLines = 0;
    
    leftBubble = [UIImage imageNamed:@"left_bubble"];
    rightBubble = [UIImage imageNamed:@"right_bubble"];
    leftBubble = [leftBubble stretchableImageWithLeftCapWidth:leftBubble.size.width*0.7 topCapHeight:leftBubble.size.height*0.3];
    rightBubble = [rightBubble stretchableImageWithLeftCapWidth:rightBubble.size.width*0.3 topCapHeight:rightBubble.size.height*0.3];
    
    background = [[UIImageView alloc] initWithFrame:CGRectMake(40, 60, _lb_Content.frame.size.width+20, _lb_Content.frame.size.height+25)];
    background.image = leftBubble;
    
    [self.contentView addSubview:_iv_UserHead];
    [self.contentView addSubview:_lb_UserName];
    [self.contentView addSubview:_lb_Content];
    [self.contentView addSubview:background];
}

- (CGFloat)setMessage:(Message *)message{
    _lb_Content.text = message.content;
    [_lb_Content sizeToFit];
    
    background.frame = CGRectMake(50, 60, _lb_Content.frame.size.width+20, _lb_Content.frame.size.height+35);
    
    if(message.isSender){
        _iv_UserHead.frame = CGRectMake(screen_Width-10-50, 5, 50, 50);
        
        _lb_UserName.frame = CGRectMake(CGRectGetMinX(_iv_UserHead.frame) - 10 - 100, 10, 100, 20);
        _lb_UserName.textAlignment = NSTextAlignmentRight;
        
        _lb_Content.frame = CGRectMake(screen_Width-60-_lb_Content.frame.size.width, 85, _lb_Content.frame.size.width, _lb_Content.frame.size.height);
        _lb_Content.textAlignment = NSTextAlignmentRight;
        
        background.frame = CGRectMake(CGRectGetMinX(_iv_UserHead.frame)-_lb_Content.frame.size.width-10, 60, _lb_Content.frame.size.width+20, _lb_Content.frame.size.height+35);
        background.image = rightBubble;
    }
    
    _iv_UserHead.image = message.userHead;
    _lb_UserName.text = message.userName;
    
    return CGRectGetMaxY(background.frame) + 8;
    
}

@end
