//
//  Message.h
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface Message : NSObject

@property (copy, nonatomic) NSString *userName;

@property (copy, nonatomic) NSString *content;

@property (nonatomic) UIImage *userHead;

@property (assign, nonatomic) BOOL isSender;

@property (assign, nonatomic) CGFloat cellHeight;

@end
