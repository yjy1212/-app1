//
//  OrderDetailViewController.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "OrderDetailViewController.h"

@interface OrderDetailViewController ()
@property (strong, nonatomic) IBOutlet UILabel *lb_OrderNumber;
@property (strong, nonatomic) IBOutlet UILabel *lb_Policyholders;
@property (strong, nonatomic) IBOutlet UILabel *lb_Insurant;
@property (strong, nonatomic) IBOutlet UILabel *lb_Beneficiary;
@property (strong, nonatomic) IBOutlet UILabel *lb_DealStatus;

@end

@implementation OrderDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _lb_OrderNumber.text = self.order.orderID;
    _lb_Policyholders.text = self.order.policyholders;
    _lb_Insurant.text = self.order.insurant;
    _lb_Beneficiary.text = self.order.beneficiary;
    _lb_DealStatus.text = self.order.dealStatus;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"保单详情";
    self.navigationController.navigationBar.items[2].title = @"返回";
    self.tabBarController.tabBar.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
