//
//  PayView.h
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PayView : UIView

@property (strong, nonatomic) UIScrollView *contentView;

@property (strong, nonatomic) UILabel *lb_OrderInfo;

@property (strong, nonatomic) UILabel *lb_OrderPrice;

@property (strong, nonatomic) UITextField *tf_Password;

- (void)show;

- (void)showInputPage;

- (void)close;

@end
