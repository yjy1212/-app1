//
//  ClaimsViewController.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "ClaimsViewController.h"

@interface ClaimsViewController () <UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *tf_OrderNumber;
@property (strong, nonatomic) IBOutlet UITextField *tf_IdentifyCode;
@property (strong, nonatomic) IBOutlet UITextField *tf_Upload;

@end

@implementation ClaimsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _tf_OrderNumber.borderStyle = UITextBorderStyleNone;
    _tf_IdentifyCode.borderStyle = UITextBorderStyleNone;
    _tf_Upload.borderStyle = UITextBorderStyleNone;
    
    _tf_Upload.delegate = self;
    
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"理赔";
    self.navigationController.navigationBar.items[0].title = @"返回";
    self.tabBarController.tabBar.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [_tf_OrderNumber resignFirstResponder];
    [_tf_IdentifyCode resignFirstResponder];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
    return YES;
}

@end
