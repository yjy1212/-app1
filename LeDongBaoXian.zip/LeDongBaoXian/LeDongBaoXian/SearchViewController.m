//
//  SearchViewController.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "Insurance.h"
#import "MainTableViewCell.h"
#import "SearchViewController.h"
#import "DetailViewController.h"

@interface SearchViewController () <UITableViewDelegate, UITableViewDataSource, UISearchResultsUpdating>
{
    NSMutableArray *searchResults;
}

@property (strong, nonatomic) UISearchController *sc_SearchController;

@property (strong, nonatomic) UITableView *tv_TableView;

@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.tv_TableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tv_TableView.delegate = self;
    self.tv_TableView.dataSource = self;
    [self.view addSubview:self.tv_TableView];
    
    self.sc_SearchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    self.sc_SearchController.searchResultsUpdater = self;
    self.sc_SearchController.dimsBackgroundDuringPresentation = NO;
    self.sc_SearchController.hidesNavigationBarDuringPresentation = NO;
    self.sc_SearchController.searchBar.placeholder = @"搜索";
    [self.sc_SearchController.searchBar setValue:@"取消" forKey:@"_cancelButtonText"];
    self.tv_TableView.tableHeaderView = self.sc_SearchController.searchBar;
    [self.sc_SearchController.searchBar sizeToFit];
    
    searchResults = [[NSMutableArray alloc] init];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"搜索保险";
    self.navigationController.navigationBar.items[0].title = @"返回";
    self.tabBarController.tabBar.hidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    if(self.sc_SearchController.isActive){
        self.sc_SearchController.active = NO;
    }
}

- (void)dealloc{
    self.sc_SearchController.searchResultsUpdater = nil;
    [self.sc_SearchController.searchBar removeFromSuperview];
    [self.sc_SearchController.view removeFromSuperview];
    self.tv_TableView.delegate = nil;
    self.tv_TableView.dataSource = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - TableView Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.sc_SearchController.isActive ? searchResults.count : _insurances.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 60*height_Offset + 8;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    MainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainTableViewCell"];
    if(!cell){
        cell = [[MainTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"MainTableViewCell"];
    }
    Insurance *insurance;
    if(self.sc_SearchController.isActive){
        insurance = searchResults[indexPath.row];
    }else{
        insurance = self.insurances[indexPath.row];
    }
    cell.lb_Type.text = insurance.insuranceName;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    DetailViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"Detail"];
    vc.insurance = self.sc_SearchController.isActive ? searchResults[indexPath.row] : self.insurances[indexPath.row];
    vc.currentIndex = 1;
    [self.navigationController pushViewController:vc animated:YES];
}


#pragma mark - SearchResultsUpdating

- (void)updateSearchResultsForSearchController:(UISearchController *)searchController{
    NSString *searchString = searchController.searchBar.text;
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.insuranceName contains[c] %@", searchString];
    if(searchResults != nil){
        [searchResults removeAllObjects];
    }
    searchResults = [NSMutableArray arrayWithArray:[self.insurances filteredArrayUsingPredicate:predicate]];
    [self.tv_TableView reloadData];
    
}


@end
