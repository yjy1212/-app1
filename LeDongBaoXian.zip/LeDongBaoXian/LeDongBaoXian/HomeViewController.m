//
//  HomeViewController.m
//  LeDongBaoXian
//
//  Created by Apple on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "JSONKit.h"
#import "HttpUtils.h"
#import "GlobalValues.h"
#import "HomeViewController.h"
#import "MainViewController.h"
#import "ServeViewController.h"
#import "ProfileViewController.h"
#import "EAccountViewController.h"

@interface HomeViewController ()

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden = NO;
    
    MainViewController *mainViewController = [storyboard instantiateViewControllerWithIdentifier:@"Main"];
    UINavigationController *nav1 = [[UINavigationController alloc] initWithRootViewController:mainViewController];
    mainViewController.title = @"首页";
    mainViewController.tabBarItem.image = [UIImage imageNamed:@"home"];
    
    ServeViewController *serveViewController = [storyboard instantiateViewControllerWithIdentifier:@"Serve"];
    UINavigationController *nav2 = [[UINavigationController alloc] initWithRootViewController:serveViewController];
    serveViewController.title = @"服务";
    serveViewController.tabBarItem.image = [UIImage imageNamed:@"message-1"];
    
    ProfileViewController *profileViewController = [storyboard instantiateViewControllerWithIdentifier:@"Profile"];
    UINavigationController *nav3 = [[UINavigationController alloc] initWithRootViewController:profileViewController];
    profileViewController.title = @"个人中心";
    profileViewController.tabBarItem.image = [UIImage imageNamed:@"person-1"];
    
    EAccountViewController *eAccountViewController = [storyboard instantiateViewControllerWithIdentifier:@"EAccount"];
    UINavigationController *nav4 = [[UINavigationController alloc] initWithRootViewController:eAccountViewController];
    eAccountViewController.title = @"E宝账";
    eAccountViewController.tabBarItem.image = [UIImage imageNamed:@"bank_card"];
    
    self.viewControllers = @[nav1, nav2, nav3, nav4];
    
    self.tabBar.barTintColor = barColor;
    
    if(GlobalIsFirstLogin){
        GlobalIsFirstLogin = NO;
        [HttpUtils getUserInfoWithUserID:GlobalUserID completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
            if(!error){
                NSDictionary *responseInfo = [responseObject objectFromJSONData];
                NSString *code = responseInfo[@"code"];
                if([code isEqualToString:@"1"]){
                    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                    GlobalUserIdentifyCode = responseInfo[@"identity"];
                    GlobalUserMoney = responseInfo[@"money"];
                    GlobalUserName = responseInfo[@"name"];
                    GlobalUserGender = responseInfo[@"sex"];
                    if(!GlobalUserIdentifyCode){
                        [userDefaults setObject:GlobalUserIdentifyCode forKey:@"UserIdentifyCode"];
                    }
                    if(!GlobalUserMoney){
                        [userDefaults setObject:GlobalUserMoney forKey:@"UserMoney"];
                    }
                    if(!GlobalUserName){
                        [userDefaults setObject:GlobalUserIdentifyCode forKey:@"UserName"];
                    }
                    if(!GlobalUserPhone){
                        [userDefaults setObject:GlobalUserPhone forKey:@"UserPhone"];
                    }
                    if(!GlobalUserGender){
                        [userDefaults setObject:GlobalUserGender forKey:@"UserGender"];
                    }
                }
            }else{
                NSLog(@"%@", error);
            }
        }];
    }
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSData *imageDate = [userDefaults objectForKey:@"UserHead"];
    GlobalUserHead = [UIImage imageWithData:imageDate];
    GlobalUserID = [userDefaults objectForKey:@"UserID"];
    GlobalUserToken = [userDefaults objectForKey:@"Token"];
    GlobalUserName = [userDefaults objectForKey:@"UserName"];
    GlobalUserPhone = [userDefaults objectForKey:@"UserPhone"];
    GlobalUserMoney = [userDefaults objectForKey:@"UserMoney"];
    GlobalUserGender = [userDefaults objectForKey:@"UserGender"];
    GlobalIsUserLogin = [userDefaults objectForKey:@"IsUserLogin"];
    GlobalVoice = [userDefaults objectForKey:@"Voice"];
    GlobalShock = [userDefaults objectForKey:@"Shock"];
    
    if(!GlobalVoice){
        GlobalVoice = @"YES";
        GlobalShock = @"YES";
        [userDefaults setObject:GlobalVoice forKey:@"Voice"];
        [userDefaults setObject:GlobalShock forKey:@"Shock"];
    }
    
    

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
