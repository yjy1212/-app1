//
//  SettingViewController.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "AppDelegate.h"
#import "LoginViewController.h"
#import "SettingViewController.h"
#import "MessageAlertViewController.h"
#import "ProfileSettingViewController.h"

@interface SettingViewController ()
@property (strong, nonatomic) IBOutlet UIView *v_ProfileSetting;
@property (strong, nonatomic) IBOutlet UIView *v_AlertSetting;
@property (strong, nonatomic) IBOutlet UIView *v_ClearCharRecode;
@property (strong, nonatomic) IBOutlet UIView *v_ClearCache;
- (IBAction)exitLogin:(UIButton *)sender;

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _v_ProfileSetting.layer.borderWidth = 0.5;
    _v_ProfileSetting.layer.borderColor = [UIColor lightGrayColor].CGColor;
    _v_AlertSetting.layer.borderWidth = 0.5;
    _v_AlertSetting.layer.borderColor = [UIColor lightGrayColor].CGColor;
    _v_ClearCharRecode.layer.borderWidth = 0.5;
    _v_ClearCharRecode.layer.borderColor = [UIColor lightGrayColor].CGColor;
    _v_ClearCache.layer.borderWidth = 0.5;
    _v_ClearCache.layer.borderColor = [UIColor lightGrayColor].CGColor;
    
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(jumpToProfileViewController)];
    [_v_ProfileSetting addGestureRecognizer:tapGesture];
    tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(jumpToMessageAlertViewController)];
    [_v_AlertSetting addGestureRecognizer:tapGesture];
    
    tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clearChatRecode)];
    [_v_ClearCharRecode addGestureRecognizer:tapGesture];
    
    tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clearCache)];
    [_v_ClearCache addGestureRecognizer:tapGesture];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"设置";
    self.navigationController.navigationBar.items[0].title = @"返回";
    self.tabBarController.tabBar.hidden = YES;
}

- (void)clearChatRecode{
    
}

- (void)clearCache{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)jumpToProfileViewController{
    ProfileSettingViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"ProfileSetting"];
    [self.navigationController pushViewController:vc animated:YES];
    
}

- (void)jumpToMessageAlertViewController{
    MessageAlertViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"MessageAlert"];
    [self.navigationController pushViewController:vc animated:YES];
    
}



- (IBAction)exitLogin:(UIButton *)sender {
    NSString *appDomain = [[NSBundle mainBundle] bundleIdentifier];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults removePersistentDomainForName:appDomain];
    [userDefaults setObject:@"NO" forKey:@"IsUserLogin"];
    
    
    AppDelegate *delegate = [UIApplication sharedApplication].delegate;
    LoginViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"Login"];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    delegate.window.rootViewController = nav;
}

@end
