//
//  Message.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "Message.h"

@implementation Message

@end
