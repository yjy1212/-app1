//
//  SearchViewController.h
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchViewController : UIViewController

@property (nonatomic) NSMutableArray *insurances;

@end
