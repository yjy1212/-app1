//
//  OrderDetailViewController.h
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "Order.h"
#import <UIKit/UIKit.h>

@interface OrderDetailViewController : UIViewController

@property (nonatomic) Order *order;

@end
