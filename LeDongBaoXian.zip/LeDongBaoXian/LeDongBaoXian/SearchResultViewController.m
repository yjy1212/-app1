//
//  SearchResultViewController.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/9.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "Order.h"
#import "iToast.h"
#import "JSONKit.h"
#import "HttpUtils.h"
#import "OrderDetailViewController.h"
#import "SearchResultViewController.h"

@interface SearchResultViewController () <UITableViewDelegate, UITableViewDataSource>

@property (strong, nonatomic) UITableView *tv_TableView;

@end

@implementation SearchResultViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tv_TableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tv_TableView.delegate = self;
    self.tv_TableView.dataSource = self;
    [self.view addSubview:self.tv_TableView];
    
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"查询结果";
    self.navigationController.navigationBar.items[1].title = @"返回";
    self.tabBarController.tabBar.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.results.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell"];
    if(!cell){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"UITableViewCell"];
    }
    Order *order = self.results[indexPath.row];
    cell.textLabel.text = order.orderID;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    OrderDetailViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"OrderDetail"];
    vc.order = self.results[indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
