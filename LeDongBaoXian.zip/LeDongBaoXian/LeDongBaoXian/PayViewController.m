//
//  PayViewController.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "iToast.h"
#import "PayView.h"
#import "PayViewController.h"

@interface PayViewController ()
@property (strong, nonatomic) IBOutlet UITextField *tf_OrderPerson;
@property (strong, nonatomic) IBOutlet UITextField *tf_IdentifyCode;
@property (strong, nonatomic) IBOutlet UITextField *tf_Phone;
@property (strong, nonatomic) IBOutlet UITextField *tf_GetInsurance;
@property (strong, nonatomic) IBOutlet UITextField *tf_ProfitPerson;
@property (strong, nonatomic) IBOutlet UILabel *lb_InsuranceType;
@property (strong, nonatomic) IBOutlet UILabel *lb_InsuranceTime;
@property (strong, nonatomic) IBOutlet UILabel *lb_InsurancePrice;

@property (strong, nonatomic) PayView *payView;


- (IBAction)buyInsurance:(UIButton *)sender;

@end

@implementation PayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.payView = [[PayView alloc] initWithFrame:self.view.frame];
    
    _tf_Phone.borderStyle = UITextBorderStyleNone;
    _tf_OrderPerson.borderStyle = UITextBorderStyleNone;
    _tf_GetInsurance.borderStyle = UITextBorderStyleNone;
    _tf_IdentifyCode.borderStyle = UITextBorderStyleNone;
    _tf_ProfitPerson.borderStyle = UITextBorderStyleNone;
    
    _lb_InsuranceType.text = self.insurance.insuranceType;
    _lb_InsuranceTime.text = [_lb_InsuranceTime.text stringByAppendingFormat:@"  %@", self.insurance.insuranceTime];
    _lb_InsurancePrice.text = [_lb_InsurancePrice.text stringByAppendingFormat:@"  %@", self.insurance.insurancePrice];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"保单确认";
    self.navigationController.navigationBar.items[self.currentIndex].title = @"返回";
    self.tabBarController.tabBar.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)buyInsurance:(UIButton *)sender {
    if([_tf_OrderPerson.text isEqualToString:@""]){
        [[[[iToast makeText:@"请输入投保人!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
        return;
    }
    if([_tf_IdentifyCode.text isEqualToString:@""]){
        [[[[iToast makeText:@"请输入身份证号!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
        return;
    }
    if([_tf_Phone.text isEqualToString:@""]){
        [[[[iToast makeText:@"请输入手机号!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
        return;
    }
    if([_tf_GetInsurance.text isEqualToString:@""]){
        [[[[iToast makeText:@"请输入被保险人!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
        return;
    }
    if([_tf_ProfitPerson.text isEqualToString:@""]){
        [[[[iToast makeText:@"请输入受益人!"] setGravity:iToastGravityBottom] setDuration:iToastDurationShort] show];
        return;
    }
    
    self.payView.lb_OrderInfo.text = self.insurance.insuranceName;
    self.payView.lb_OrderPrice.text = self.insurance.insurancePrice;
    
    [self.payView show];
}
@end
