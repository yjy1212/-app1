//
//  MainTableViewCell.m
//  LeDongBaoXian
//
//  Created by 杭州歇尔科技有限公司 on 16/6/8.
//  Copyright © 2016年 Unuse. All rights reserved.
//

#import "MainTableViewCell.h"

@implementation MainTableViewCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if(self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]){
        [self setup];
    }
    return self;
}

- (void)setup{
    self.contentView.backgroundColor = [UIColor grayColor];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    _iv_MainImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 2, 100*width_Offset, 60*height_Offset)];
    [self.contentView addSubview:_iv_MainImage];
    
    _lb_Type = [[UILabel alloc] initWithFrame:CGRectMake(100*width_Offset, 2, screen_Width-100*width_Offset, 60*height_Offset)];
    _lb_Type.font = [UIFont boldSystemFontOfSize:20*height_Offset];
    _lb_Type.backgroundColor = [UIColor whiteColor];
    [self.contentView addSubview:_lb_Type];
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(screen_Width-40*width_Offset, 30*height_Offset-10*height_Offset, 15*width_Offset, 20*height_Offset)];
    imageView.center = CGPointMake(imageView.center.x, _lb_Type.center.y);
    imageView.image = [UIImage imageNamed:@"arrow"];
    [self.contentView addSubview:imageView];
    
}

@end
